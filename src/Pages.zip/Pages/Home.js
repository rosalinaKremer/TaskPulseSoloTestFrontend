import { useState, useEffect, useRef } from "react";
import "../css/Home.css";
import Profile from "./Profile";

const HOME_VIEW_KEY = "taskpulse.homeView";
const API_BASE = "http://localhost:8080/api/tasks";

function CategoryIcon({ name }) {
  const svgProps = {
    width: "18", height: "18", viewBox: "0 0 24 24", fill: "none",
    stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round"
  };

  const icons = {
    "all-tasks": <><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></>,
    "cleaning": <><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></>,
    "plumbing": <><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></>,
    "electrical": <><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></>,
    "delivery": <><line x1="16.5" y1="9.4" x2="7.5" y2="4.21"/><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></>,
    "tutoring": <><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></>,
    "gardening": <><path d="M12 22V12"/><path d="M12 12A4 4 0 0 0 8 8V4h4a4 4 0 0 1 4 4"/><path d="M12 16a4 4 0 0 0 4-4v-4h-4a4 4 0 0 0-4 4"/></>,
    "carpentry": <><rect x="3" y="8" width="18" height="6" rx="2"/><line x1="12" y1="14" x2="12" y2="22"/></>,
    "moving": <><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></>,
    "pets": <><path d="M12 12c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5z"/><path d="M18.5 10c-1.38 0-2.5-1.12-2.5-2.5S17.12 5 18.5 5 21 6.12 21 7.5 19.88 10 18.5 10z"/><path d="M5.5 10C4.12 10 3 8.88 3 7.5S4.12 5 5.5 5 8 6.12 8 7.5 6.88 10 5.5 10z"/><path d="M12 7c-1.38 0-2.5-1.12-2.5-2.5S10.62 2 12 2s2.5 1.12 2.5 2.5S13.38 7 12 7z"/></>
  };
  return <svg {...svgProps}>{icons[name] || icons["all-tasks"]}</svg>;
}

const categories = [
  { name: "All Tasks", iconId: "all-tasks" },
  { name: "Home Cleaning", iconId: "cleaning" },
  { name: "Plumbing", iconId: "plumbing" },
  { name: "Electrical", iconId: "electrical" },
  { name: "Delivery", iconId: "delivery" },
  { name: "Tutoring", iconId: "tutoring" },
  { name: "Gardening", iconId: "gardening" },
  { name: "Carpentry", iconId: "carpentry" },
  { name: "Moving", iconId: "moving" },
  { name: "Pet Care", iconId: "pets" },
];

export default function Home({ user, token, onLogout }) {
  // ── Database State ──
  const [tasks, setTasks] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  // ── UI States ──
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("All Tasks");
  const [appMode, setAppMode] = useState("tasker"); 
  const categoryScrollRef = useRef(null);
  
  // ── Filter States ──
  const [showFilters, setShowFilters] = useState(false);
  const [filterMinBudget, setFilterMinBudget] = useState("");
  const [filterMaxBudget, setFilterMaxBudget] = useState("");
  const [filterUrgent, setFilterUrgent] = useState(false);

  // ── Modal States (Create & Edit) ──
  const [taskModal, setTaskModal] = useState({ isOpen: false, mode: 'create', id: null });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [taskForm, setTaskForm] = useState({
    title: "", category: "Home Cleaning", location: "", price: "", description: "", urgent: false
  });

  const [showProfile, setShowProfile] = useState(() => localStorage.getItem(HOME_VIEW_KEY) === "profile");

  // ── Fetch Tasks from Backend ──
  const loadTasks = async () => {
    setIsLoading(true);
    try {
      const res = await fetch(`${API_BASE}/available`, {
        headers: { "Authorization": "Bearer " + token }
      });
      const data = await res.json();
      if (Array.isArray(data)) setTasks(data);
    } catch (e) {
      console.error("Failed to load tasks", e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => { loadTasks(); }, []);

  // ── Save Task (Create or Edit) ──
  const handleSaveTask = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      const isEdit = taskModal.mode === 'edit';
      const url = isEdit ? `${API_BASE}/${taskModal.id}?email=${user}` : `${API_BASE}?email=${user}`;
      const method = isEdit ? "PUT" : "POST";

      const res = await fetch(url, {
        method,
        headers: { "Authorization": "Bearer " + token, "Content-Type": "application/json" },
        body: JSON.stringify(taskForm)
      });
      
      const data = await res.json();
      if (!data.success) throw new Error(data.error);
      
      closeTaskModal();
      await loadTasks(); // Refresh the feed!
    } catch (err) {
      alert("Failed to save task: " + err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const openCreateModal = () => {
    setTaskForm({ title: "", category: "Home Cleaning", location: "", price: "", description: "", urgent: false });
    setTaskModal({ isOpen: true, mode: 'create', id: null });
  };

  const openEditModal = (task) => {
    setTaskForm({ 
      title: task.title, category: task.category, location: task.location, 
      price: task.price, description: task.description, urgent: task.urgent 
    });
    setTaskModal({ isOpen: true, mode: 'edit', id: task.id });
  };

  const closeTaskModal = () => setTaskModal({ isOpen: false, mode: 'create', id: null });

  function scrollCategories(direction) {
    if (categoryScrollRef.current) {
      const scrollAmount = 250; 
      categoryScrollRef.current.scrollBy({ left: direction === "left" ? -scrollAmount : scrollAmount, behavior: "smooth" });
    }
  }

  function clearFilters() {
    setFilterMinBudget(""); setFilterMaxBudget(""); setFilterUrgent(false);
  }

  const hasActiveFilters = filterMinBudget || filterMaxBudget || filterUrgent;

  if (showProfile) {
    return <Profile user={user} token={token} onLogout={onLogout} onBack={() => { setShowProfile(false); localStorage.setItem(HOME_VIEW_KEY, "home"); }} />;
  }

  // ── Filtering Logic ──
  const normalizedQuery = searchQuery.trim().toLowerCase();
  const filteredTasks = tasks.filter((p) => {
    const matchesQuery = !normalizedQuery || p.title.toLowerCase().includes(normalizedQuery) || p.location.toLowerCase().includes(normalizedQuery);
    const matchesCategory = activeCategory === "All Tasks" || p.category === activeCategory;
    const min = filterMinBudget ? Number(filterMinBudget) : 0;
    const max = filterMaxBudget ? Number(filterMaxBudget) : Infinity;
    const matchesBudget = p.price >= min && p.price <= max;
    const matchesUrgent = !filterUrgent || p.urgent === true;
    return matchesQuery && matchesCategory && matchesBudget && matchesUrgent;
  });

  return (
    <div className="tp-feed-root">
      
      {/* ── Top Header ── */}
      <header className="tp-feed-header">
        <div className="tp-feed-brand">TaskPulse</div>

        <div className="tp-mode-toggle">
          <button className={`tp-mode-btn ${appMode === 'tasker' ? 'active' : ''}`} onClick={() => setAppMode('tasker')}>Find Work</button>
          <button className={`tp-mode-btn ${appMode === 'poster' ? 'active' : ''}`} onClick={() => setAppMode('poster')}>My Posts</button>
        </div>

        <div className="tp-feed-actions">
          <button className="tp-feed-post-btn" onClick={openCreateModal}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
              <line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line>
            </svg>
            <span className="hide-mobile">New Task</span>
          </button>
          <button className="tp-feed-avatar" onClick={() => { setShowProfile(true); localStorage.setItem(HOME_VIEW_KEY, "profile"); }}>
             <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="8" r="4" /><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" />
            </svg>
          </button>
        </div>
      </header>

      {/* ── Search & Filter Strip ── */}
      {appMode === 'tasker' && (
        <div className="tp-filter-strip-container">
          <div className="tp-filter-strip">
            <div className="tp-feed-search">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" /></svg>
              <input type="text" placeholder="Search tasks or locations..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
            </div>

            <div className="tp-category-wrapper">
              <button className="tp-scroll-arrow left" onClick={() => scrollCategories('left')}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg>
              </button>
              
              <div className="tp-category-scroll" ref={categoryScrollRef}>
                {categories.map((cat) => (
                  <button key={cat.name} className={`tp-cat-pill ${activeCategory === cat.name ? 'active' : ''}`} onClick={() => setActiveCategory(cat.name)}>
                    <span className="tp-cat-pill-icon" style={{display: 'flex', alignItems: 'center'}}><CategoryIcon name={cat.iconId} /></span>
                    {cat.name}
                  </button>
                ))}
              </div>

              <button className="tp-scroll-arrow right" onClick={() => scrollCategories('right')}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>
              </button>
            </div>

            <button className={`tp-advanced-filter-btn ${hasActiveFilters ? 'has-filters' : ''}`} onClick={() => setShowFilters(true)}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                <line x1="4" y1="21" x2="4" y2="14"></line><line x1="4" y1="10" x2="4" y2="3"></line><line x1="12" y1="21" x2="12" y2="12"></line><line x1="12" y1="8" x2="12" y2="3"></line><line x1="20" y1="21" x2="20" y2="16"></line><line x1="20" y1="12" x2="20" y2="3"></line><line x1="1" y1="14" x2="7" y2="14"></line><line x1="9" y1="8" x2="15" y2="8"></line><line x1="17" y1="16" x2="23" y2="16"></line>
              </svg>
              Filters {hasActiveFilters && <span className="tp-filter-dot"></span>}
            </button>
          </div>
        </div>
      )}

      {/* ── Main Content Area ── */}
      <main className="tp-feed-main">
        {appMode === 'tasker' ? (
          <>
            <div className="tp-feed-header-text">
              <h2>{activeCategory === "All Tasks" ? "Latest Opportunities" : `${activeCategory} Tasks`}</h2>
              <p>{isLoading ? "Loading tasks..." : `${filteredTasks.length} tasks available`}</p>
            </div>

            <div className="tp-feed-grid">
              {!isLoading && filteredTasks.map((p) => (
                <article key={p.id} className="tp-gig-card">
                  <div className="tp-gig-top">
                    <div className="tp-gig-meta">
                      <span className="tp-gig-cat">{p.category}</span>
                      <span className="tp-gig-time">• {p.time}</span>
                    </div>
                    {p.urgent && <span className="tp-gig-urgent">Urgent</span>}
                  </div>

                  <h3 className="tp-gig-title">{p.title}</h3>
                  <p style={{fontSize: '0.85rem', color: '#64748b', marginBottom: '1rem', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden'}}>{p.description}</p>
                  
                  <div className="tp-gig-location">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" /><circle cx="12" cy="10" r="3" /></svg>
                    {p.location}
                  </div>

                  <div className="tp-gig-bottom">
                    <div className="tp-gig-price-info">
                      <div className="tp-gig-price">₱{Number(p.price).toLocaleString()}</div>
                      <div className="tp-gig-bids">{p.bids} active bids</div>
                    </div>
                    
                    {/* ONLY SHOW EDIT IF THIS USER OWNS THE TASK */}
                    {p.creatorEmail === user ? (
                      <button className="tp-gig-action-btn" style={{background: '#f1f5f9', color: '#0f172a'}} onClick={() => openEditModal(p)}>Edit Task</button>
                    ) : (
                      <button className="tp-gig-action-btn">Place Bid</button>
                    )}
                  </div>
                </article>
              ))}

              {!isLoading && filteredTasks.length === 0 && (
                <div className="tp-feed-empty">
                  <div className="tp-feed-empty-icon">🍃</div>
                  <h3>No tasks found</h3>
                  <p>Try adjusting your budget or clearing your filters to see more.</p>
                  <button className="tp-feed-post-btn" style={{marginTop: "1.5rem", width: "auto"}} onClick={clearFilters}>Clear All Filters</button>
                </div>
              )}
            </div>
          </>
        ) : (
          <div className="tp-poster-dashboard">
            <div className="tp-poster-header">
              <h2>Your Posted Tasks</h2>
              <p>Manage your requests and review bids from local Taskers.</p>
            </div>
            
            {/* Filter to only show tasks owned by this user in "My Posts" */}
            <div className="tp-feed-grid">
              {tasks.filter(t => t.creatorEmail === user).map(p => (
                 <article key={p.id} className="tp-gig-card">
                  <div className="tp-gig-top">
                    <div className="tp-gig-meta"><span className="tp-gig-cat">{p.category}</span></div>
                    {p.urgent && <span className="tp-gig-urgent">Urgent</span>}
                  </div>
                  <h3 className="tp-gig-title">{p.title}</h3>
                  <div className="tp-gig-bottom">
                    <div className="tp-gig-price-info">
                      <div className="tp-gig-price">₱{Number(p.price).toLocaleString()}</div>
                    </div>
                    <button className="tp-gig-action-btn" style={{background: '#f1f5f9', color: '#0f172a'}} onClick={() => openEditModal(p)}>Edit Task</button>
                  </div>
                </article>
              ))}
              
              {tasks.filter(t => t.creatorEmail === user).length === 0 && (
                <div className="tp-feed-empty">
                  <div className="tp-feed-empty-icon">📝</div>
                  <h3>You haven't posted any tasks yet</h3>
                  <button className="tp-feed-post-btn" style={{marginTop: '1.5rem', width: 'auto'}} onClick={openCreateModal}>Create Your First Post</button>
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* ── CREATE / EDIT TASK MODAL ── */}
      {taskModal.isOpen && (
        <div className="tp-filter-modal-overlay" onClick={(e) => e.target === e.currentTarget && closeTaskModal()}>
          <div className="tp-filter-modal">
            <div className="tp-filter-modal-header">
              <h2>{taskModal.mode === 'edit' ? 'Edit Task' : 'Post a New Task'}</h2>
              <button className="tp-close-btn" onClick={closeTaskModal}>✕</button>
            </div>

            <form onSubmit={handleSaveTask} className="tp-filter-body" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div className="tp-input-group" style={{ marginBottom: 0 }}>
                <label>Task Title</label>
                <input required type="text" placeholder="e.g. Fix leaking kitchen pipe" value={taskForm.title} onChange={e => setTaskForm({...taskForm, title: e.target.value})} />
              </div>

              <div className="tp-input-group" style={{ marginBottom: 0 }}>
                <label>Category</label>
                <select style={{ width: '100%', padding: '0.75rem 1rem', border: '1px solid #cbd5e1', borderRadius: '10px', background: '#f8fafc', outline: 'none' }} value={taskForm.category} onChange={e => setTaskForm({...taskForm, category: e.target.value})}>
                  {categories.filter(c => c.name !== "All Tasks").map(cat => <option key={cat.name} value={cat.name}>{cat.name}</option>)}
                </select>
              </div>

              <div style={{ display: 'flex', gap: '1rem' }}>
                <div className="tp-input-group" style={{ marginBottom: 0, flex: 1 }}>
                  <label>Location</label>
                  <input required type="text" placeholder="e.g. Cebu City" value={taskForm.location} onChange={e => setTaskForm({...taskForm, location: e.target.value})} />
                </div>
                <div className="tp-input-group" style={{ marginBottom: 0, flex: 1 }}>
                  <label>Price (₱)</label>
                  <input required type="number" min="1" placeholder="e.g. 500" value={taskForm.price} onChange={e => setTaskForm({...taskForm, price: e.target.value})} />
                </div>
              </div>

              <div className="tp-input-group" style={{ marginBottom: 0 }}>
                <label>Description details</label>
                <textarea required placeholder="Describe what you need help with..." style={{ minHeight: '80px' }} value={taskForm.description} onChange={e => setTaskForm({...taskForm, description: e.target.value})} />
              </div>

              <label className="tp-checkbox-label" style={{ marginTop: '0.5rem' }}>
                <div className="tp-checkbox-text">
                  <span className="tp-checkbox-title">Mark as Urgent?</span>
                  <span className="tp-filter-desc" style={{ marginBottom: 0 }}>Highlights your task to local taskers.</span>
                </div>
                <div className={`tp-custom-toggle ${taskForm.urgent ? 'active' : ''}`} onClick={() => setTaskForm({...taskForm, urgent: !taskForm.urgent})}>
                  <div className="tp-toggle-knob"></div>
                </div>
              </label>

              <div className="tp-filter-modal-actions" style={{ padding: '1rem 0 0', marginTop: '0.5rem' }}>
                <button type="button" className="tp-btn-clear" onClick={closeTaskModal}>Cancel</button>
                <button type="submit" className="tp-btn-apply" disabled={isSubmitting}>{isSubmitting ? "Saving..." : (taskModal.mode === 'edit' ? "Save Changes" : "Post Task")}</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ── ADVANCED FILTERS MODAL ── */}
      {showFilters && (
        <div className="tp-filter-modal-overlay" onClick={(e) => e.target === e.currentTarget && setShowFilters(false)}>
          <div className="tp-filter-modal">
            <div className="tp-filter-modal-header">
              <h2>Advanced Filters</h2>
              <button className="tp-close-btn" onClick={() => setShowFilters(false)}>✕</button>
            </div>
            <div className="tp-filter-body">
              <div className="tp-filter-group">
                <label>Budget Range (₱)</label>
                <p className="tp-filter-desc">Find tasks that fit your expected payout.</p>
                <div className="tp-budget-inputs">
                  <div className="tp-budget-input-wrap"><span className="tp-currency">₱</span><input type="number" placeholder="Min" value={filterMinBudget} onChange={(e) => setFilterMinBudget(e.target.value)} /></div>
                  <span className="tp-budget-dash">-</span>
                  <div className="tp-budget-input-wrap"><span className="tp-currency">₱</span><input type="number" placeholder="Max" value={filterMaxBudget} onChange={(e) => setFilterMaxBudget(e.target.value)} /></div>
                </div>
              </div>
              <div className="tp-filter-group" style={{marginTop: "2rem"}}>
                <label className="tp-checkbox-label">
                  <div className="tp-checkbox-text">
                    <span className="tp-checkbox-title">Urgent Tasks Only</span>
                    <span className="tp-filter-desc">Show tasks that need immediate attention.</span>
                  </div>
                  <div className={`tp-custom-toggle ${filterUrgent ? 'active' : ''}`} onClick={() => setFilterUrgent(!filterUrgent)}><div className="tp-toggle-knob"></div></div>
                </label>
              </div>
            </div>
            <div className="tp-filter-modal-actions">
              <button className="tp-btn-clear" onClick={clearFilters}>Clear All</button>
              <button className="tp-btn-apply" onClick={() => setShowFilters(false)}>Apply Filters</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}